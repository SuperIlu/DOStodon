var TITLE_HEIGHT = 10;
var BORDER_WIDTH = 1;

var wmWindows = [];
var wmFont = new Font();
var wmLastLMB = false;
var wmDragging = null;

function WMWindow(x, y, w, h, title, onExit) {
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.title = title;

	this.children = [];
	this.content = new Bitmap(w, h, EGA.BLACK);
	this.visible = false;
	this.selected = false;

	var outer = this;
	onExit = onExit || function () { outer.Show(false) };
	new WMButton(this, this.w - TITLE_HEIGHT, 0, TITLE_HEIGHT, TITLE_HEIGHT, "X", onExit);

	wmWindows.push(this);
}

WMWindow.prototype.Draw = function () {
	if (this.visible) {
		var yEnd = this.y + this.h + BORDER_WIDTH;
		var xEnd = this.x + this.w + BORDER_WIDTH;

		// upper and left border
		Line(this.x, this.y, xEnd, this.y, this.selected ? EGA.RED : EGA.WHITE);
		Line(this.x, this.y, this.x, yEnd, this.selected ? EGA.RED : EGA.WHITE);

		// lower and right border
		Line(this.x, yEnd, xEnd, yEnd, this.selected ? EGA.RED : EGA.DARK_GREY);
		Line(xEnd, this.y, xEnd, yEnd, this.selected ? EGA.RED : EGA.DARK_GREY);

		// draw window content
		SetRenderBitmap(this.content);

		// draw window handle
		var yPos = 0;
		FilledBox(0, yPos, this.w, TITLE_HEIGHT, EGA.LIGHT_BLUE);
		yPos += TITLE_HEIGHT;
		Line(0, yPos, this.w, yPos, EGA.DARK_GREY);
		yPos += BORDER_WIDTH;
		Line(0, yPos, this.w, yPos, EGA.WHITE);
		yPos += BORDER_WIDTH;

		// draw title
		if (this.title) {
			wmFont.DrawStringLeft(BORDER_WIDTH, 2 * BORDER_WIDTH, this.title, EGA.BLACK, NO_COLOR);
		}

		for (var i = 0; i < this.children.length; i++) {
			this.children[i].Draw();
		}
		SetRenderBitmap(null);
		this.content.Draw(this.x + BORDER_WIDTH, this.y + BORDER_WIDTH);
	}
}

WMWindow.prototype.Unselect = function () {
	this.selected = false;
	this.children.forEach(function (c) { c.Unselect() });
}

WMWindow.prototype.Input = function (e) {
	var w = FindFrontmostWidget(this.children, {
		x: e.x - (this.x + BORDER_WIDTH),
		y: e.y - (this.y + BORDER_WIDTH),
		buttons: e.buttons
	});
	if (w) {
		w.Input(e);
	}
}

WMWindow.prototype.Show = function (val) {
	this.visible = val;
}

WMWindow.prototype.ToFront = function () {
	ArrayRemove(wmWindows, this);
	wmWindows.push(this);
}

WMWindow.prototype.ToBack = function () {
	ArrayRemove(wmWindows, this);
	wmWindows.unshift(this);
}

WMWindow.prototype.Destroy = function () {
	this.Close();
	ArrayRemove(wmWindows, this);
}

function WMButton(parent, x, y, w, h, text, onClick) {
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.text = text;
	this.onClick = onClick;
	this.selected = false;

	parent.children.push(this);
}

WMButton.prototype.Draw = function () {
	var yEnd = this.y + this.h + BORDER_WIDTH;
	var xEnd = this.x + this.w + BORDER_WIDTH;

	// upper and left border
	Line(this.x, this.y, xEnd, this.y, this.selected ? EGA.DARK_GREY : EGA.WHITE);
	Line(this.x, this.y, this.x, yEnd, this.selected ? EGA.DARK_GREY : EGA.WHITE);

	// lower and right border
	Line(this.x, yEnd, xEnd, yEnd, this.selected ? EGA.WHITE : EGA.DARK_GREY);
	Line(xEnd, this.y, xEnd, yEnd, this.selected ? EGA.WHITE : EGA.DARK_GREY);

	FilledBox(
		this.x + BORDER_WIDTH,
		this.y + BORDER_WIDTH,
		xEnd - BORDER_WIDTH,
		this.y + this.h + BORDER_WIDTH,
		this.selected ? EGA.YELLOW : EGA.LIGHT_GREY);

	wmFont.DrawStringCenter(this.x + this.w / 2, this.y + this.h / 2 - wmFont.height / 2, this.text, EGA.BLACK, NO_COLOR);
}

WMButton.prototype.Unselect = function () {
	this.selected = false;
}

WMButton.prototype.Input = function (e) {
	var currentLMB = e.buttons == MOUSE.Buttons.LEFT;
	if (currentLMB && !this.selected) {
		this.onClick();
		this.selected = true;
	} else {
		this.selected = false;
	}
}

function ArrayRemove(arr, value) {
	return arr.filter(function (ele) {
		return ele != value;
	});
}

function IsIn(x, y, w, h, xPos, yPos) {
	return xPos >= x && xPos <= x + w && yPos >= y && yPos <= y + h;
}

function WMDraw() {
	ClearScreen(EGA.LIGHT_GREY);
	for (var i = 0; i < wmWindows.length; i++) {
		wmWindows[i].Draw();
	}
}

function FindFrontmostWidget(list, e) {
	var ret = null;

	// check if mouseclick is in a window, frontmost window wins
	for (var i = 0; i < list.length; i++) {
		var w = list[i];
		w.Unselect();
		if (IsIn(w.x, w.y, w.w, w.h, e.x, e.y)) {
			ret = w;
		}
	}

	return ret;
}

function WMInput(e) {
	var currentLMB = e.buttons == MOUSE.Buttons.LEFT;

	if (wmDragging) {
		// check if we are already dragging
		if (currentLMB) {
			// continue dragging
			var offsetX = e.x - wmDragging.x;
			var offsetY = e.y - wmDragging.y;

			wmDragging.win.x += offsetX;
			wmDragging.win.y += offsetY;

			if (wmDragging.win.x < 0) {
				wmDragging.win.x = 0;
			}
			if (wmDragging.win.y < 0) {
				wmDragging.win.y = 0;
			}

			wmDragging.x = e.x;
			wmDragging.y = e.y;
		} else {
			// button up detected
			if (wmDragging) {
				wmDragging.win.selected = false;
				wmDragging = null;
			}
		}
	} else {
		// not yet dragging, check if we are in a window
		var win = FindFrontmostWidget(wmWindows, e);
		if (win) {
			// check if button is down
			if (currentLMB) {
				win.ToFront();
				if (IsIn(win.x, win.y, win.w, TITLE_HEIGHT, e.x, e.y)) {
					// start dragging event if window was found
					wmDragging = {
						"x": e.x,
						"y": e.y,
						"win": win
					};
					win.selected = true;
				}
			}
			win.Input(e);	// pass the event to the window
		}
	}
}

// export functions and version
exports.__VERSION__ = 1;
exports.WMWindow = WMWindow;
exports.WMButton = WMButton;
exports.WMDraw = WMDraw;
exports.WMInput = WMInput;
