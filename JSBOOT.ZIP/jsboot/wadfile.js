/*
see
- https://www.cyotek.com/blog/reading-doom-wad-files
- https://github.com/ZDoom/wadext
- https://github.com/jmtd/hwadtools
- https://doomwiki.org/wiki/Picture_format
- https://doomwiki.org/wiki/Flat
- 
*/
var LUMP_SIZE = 16;

function WadFile(fname) {
	var f = new File(fname, FILE.READ);
	this.data = f.ReadInts();
	f.Close();

	if (this.data.length < 12) {
		throw new Error("[WAD] File to small: " + fname);
	}

	var p = 0;
	if (
		this.data.Get(0) === CharCode('I') ||
		this.data.Get(1) === CharCode('W') ||
		this.data.Get(2) === CharCode('A') ||
		this.data.Get(3) === CharCode('D')
	) {
		this.type = "IWAD";
	} else if (
		this.data.Get(0) === CharCode('P') ||
		this.data.Get(1) === CharCode('W') ||
		this.data.Get(2) === CharCode('A') ||
		this.data.Get(3) === CharCode('D')
	) {
		this.type = "PWAD";
	} else {
		throw new Error("[WAD] Not a WAD: " + fname);
	}
	p = 4;
	dbg("type=" + this.type);

	// read lumb count and dir pos
	this.lumpCount = ReadUint32LE(this.data, p);
	p += 4;
	dbg("lump count=" + this.lumpCount);

	this.dirStart = ReadUint32LE(this.data, p);
	p += 4;
	dbg("dir start=" + this.dirStart);

	// check sizes
	if (this.lumpCount * LUMP_SIZE > this.data.length) {
		throw new Error("[WAD] Format error, lump cound exceeds file size: " + fname);
	}

	this.lumps = [];
	for (var i = 0; i < this.lumpCount; i++) {
		this.lumps.push(new WadLump(this.data, this.dirStart + i * LUMP_SIZE));
	}
};

function WadLump(data, p) {
	this.start = ReadUint32LE(data, p);
	p += 4;

	this.size = ReadUint32LE(data, p);
	p += 4;

	this.name = "";
	while (data.Get(p) && this.name.length < 8) {
		this.name += String.fromCharCode(data.Get(p));
		p++;
	}

	dbg("name=" + this.name);
	dbg("start=" + this.start);
	dbg("size=" + this.size);
}

/**
 * Read a 32 bit unsigned, little endian number from an ByteArray.
 * 
 * @param {ByteArray} data the data to read from
 * @param {Number} pos The position to start reading from.
 * 
 * @returns {Number} the resulting 32bit number
 */
function ReadUint32LE(data, pos) {
	return (data.Get(pos + 3) << 24) | (data.Get(pos + 2) << 16) | (data.Get(pos + 1) << 8) | (data.Get(pos));
}

function dbg(s) {
	Println("[WAD] " + s);
}

// export functions and version
exports.__VERSION__ = 1;
exports.WadFile = WadFile;
